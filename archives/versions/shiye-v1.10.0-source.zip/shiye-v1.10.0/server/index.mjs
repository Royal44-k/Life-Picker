import {createXhsWebSession} from './xhs-web.mjs';
import {createDesignSources} from './design-sources.mjs';
import {createXhsCollection} from './xhs-collection.mjs';
import {createUsageStore} from './usage-store.mjs';
import { createServer } from 'node:http';
import { existsSync, readFileSync } from 'node:fs';
import { resolve, extname, sep } from 'node:path';
import { networkInterfaces } from 'node:os';
import { randomInt } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createAiHandler } from './ai.mjs';
import {createVideoService} from './video-jobs.mjs';
import {createVideoHandler} from './video-api.mjs';
import {createSourceStore,recoverSourceStore} from './source-store.mjs';
import {createSourceHandler} from './source-api.mjs';
import {createPublicAssetCache} from './source-assets.mjs';
import {createSourceJobs} from './source-jobs.mjs';
const root=resolve(fileURLToPath(new URL('..',import.meta.url)));
if(existsSync(resolve(root,'.env')))process.loadEnvFile(resolve(root,'.env'));
const port=Number(process.env.PORT||5173);const production=process.argv.includes('--prod');
const pairCode=String(randomInt(10000000,100000000));
const config={deepseekKey:process.env.DEEPSEEK_API_KEY||'',deepseekModel:process.env.DEEPSEEK_MODEL||'deepseek-flash',ollamaModel:process.env.OLLAMA_MODEL||''};
let usage=null;try{usage=await createUsageStore({root:resolve(root,'.local/ai-usage')});}catch{console.error('AI 用量账本暂时无法读取，新 AI 调用已暂停，原文件保留。');}
const api=createAiHandler(config,pairCode,fetch,{usage,getInspirationSource:async id=>sourceStore?(await sourceStore.published()).find(r=>r.id===id):null});
const videoService=await createVideoService({root:resolve(root,'.local/video-jobs',String(port))});
const videoApi=createVideoHandler(videoService,pairCode);
const sourceRoot=resolve(root,'.local/source-catalog',String(port));
let sourceStore=null;
try{sourceStore=await createSourceStore({root:sourceRoot});}
catch{console.error('来源库暂时无法读取，原文件保留。可在“我的 → 来源与审核”使用备份修复，其他功能仍可使用。');}
let sourceAssets=null,sourceJobs=null;
try{
 sourceAssets=await createPublicAssetCache({root:resolve(root,'.local/source-assets',String(port))});
 sourceJobs=await createSourceJobs({root:resolve(root,'.local/source-jobs',String(port)),getStore:()=>sourceStore,assets:sourceAssets});
}catch{console.error('公开素材任务暂时无法启动，原任务文件保留。手动来源仍可管理。');}
const xhsSession=createXhsWebSession({profile:resolve(root,'.local/xhs-web-session')});
let xhs=null;try{xhs=await createXhsCollection({root:resolve(root,'.local/xhs-state',String(port)),getStore:()=>sourceStore,transport:xhsSession.transport,runtime:xhsSession.runtime});}catch{console.error('个人来源状态暂时无法读取，已暂停连接，手动来源仍可使用。');}
let designs=null;try{designs=await createDesignSources({root:resolve(root,'.local/design-sources',String(port)),getStore:()=>sourceStore});}catch{console.error('开放设计发现暂不可用，已有来源保留。');}
const sourceApi=createSourceHandler(sourceStore,pairCode,{assets:sourceAssets,jobs:sourceJobs,xhs,designs,recover:async bundle=>{
 const result=await recoverSourceStore({root:sourceRoot,bundle});sourceStore=result.store;return result;
}});
const localIps=Object.values(networkInterfaces()).flat().filter(x=>x?.family==='IPv4'&&!x.internal).map(x=>x.address);
const hosts=new Set(['localhost','127.0.0.1',...localIps]);
const vite=production?null:await(await import('vite')).createServer({root,server:{middlewareMode:true,host:'0.0.0.0',hmr:false,watch:{ignored:['**/artifacts/**','**/.local/**','**/releases/**','**/docs/**','**/tests/**','**/.env*']}},appType:'spa'});
const dist=resolve(root,'dist');
if(production&&!existsSync(resolve(dist,'index.html'))){console.error('请先运行 npm run build 生成应用。');process.exit(1);}
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png','.svg':'image/svg+xml','.txt':'text/plain; charset=utf-8'};
const server=createServer(async(req,res)=>{
  const hostname=(req.headers.host||'').split(':')[0];
  if(!hosts.has(hostname)){res.writeHead(403);res.end('Host not allowed');return;}
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');
  try{const parts=decodeURIComponent(new URL(req.url,'http://localhost').pathname).replace(/\\/g,'/').toLowerCase().split('/');if(parts.includes('.local')){res.writeHead(403);res.end('Private runtime path');return;}}catch{res.writeHead(400);res.end('Bad request');return;}
  if(req.url?.startsWith('/api/sources/')){await sourceApi(req,res);return;}
  if(req.url?.startsWith('/api/video/')){await videoApi(req,res);return;}
  if(req.url?.startsWith('/api/')){await api(req,res);return;}
  if(vite){vite.middlewares(req,res);return;}
  try{
    const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    let file=resolve(dist,`.${path==='/'?'/index.html':path}`);
    if(!file.startsWith(dist+sep)){res.writeHead(403);res.end();return;}
    if(!existsSync(file)){res.writeHead(404);res.end('Not found');return;}
    res.setHeader('Content-Type',mime[extname(file)]||'application/octet-stream');
    res.setHeader('Cache-Control',file.includes(`${sep}assets${sep}`)?'public, max-age=31536000, immutable':'no-cache');res.end(readFileSync(file));
  }catch{res.writeHead(400);res.end('Bad request');}
});
server.on('close',()=>{sourceJobs?.close();xhs?.close();});
for(const signal of ['SIGTERM','SIGINT'])process.once(signal,()=>{xhs?.close();sourceJobs?.close();server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),1000).unref();});
server.listen(port,'0.0.0.0',()=>{
  sourceJobs?.startScheduler();xhs?.startScheduler();
  console.log(`\n拾页已启动 · 保持此窗口运行\n电脑地址：http://localhost:${port}\n`);
  for(const ip of localIps)console.log(`iPhone 同一 Wi-Fi 打开：http://${ip}:${port}`);
  console.log(`\nAI 连接码：${pairCode}\nDeepSeek：${config.deepseekKey?'已配置':'尚未配置'}；Ollama：${config.ollamaModel||'尚未配置'}\n停止运行：Ctrl+C\n`);
});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?`端口 ${port} 正在使用。若拾页已开着，请直接访问；否则关闭旧窗口后重试。`:e.message);process.exit(1);});
